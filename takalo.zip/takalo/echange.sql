DROP DATABASE Echange;

CREATE DATABASE Echange;

USE Echange;

CREATE TABLE User (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL,
    estAdmin INTEGER DEFAULT 0
);

CREATE TABLE Categorie (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Objet (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    idUser INTEGER NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prix DOUBLE NOT NULL,
    description TEXT NOT NULL,
    image VARCHAR(255) NOT NULL,
    idCategorie INTEGER NOT NULL,
    datePub TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(idUser) REFERENCES User(id),
    FOREIGN KEY(idCategorie) REFERENCES Categorie(id)
);

CREATE TABLE Echange (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    idObjetPropose INTEGER NOT NULL,
    idObjetDemande INTEGER NOT NULL,
    idUserPropose INTEGER NOT NULL,
    idUserDemande INTEGER NOT NULL,
    status ENUM('0','10','-10'),
    dateEchange TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (idObjetPropose) REFERENCES Objet(id),
    FOREIGN KEY (idObjetDemande) REFERENCES Objet(id),
    FOREIGN KEY (idUserPropose) REFERENCES User(id),
    FOREIGN KEY (idUserDemande) REFERENCES User (id)
);


CREATE TABLE Notification (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    idUser INTEGER NOT NULL,
    idEchange INTEGER NOT NULL,
    type ENUM('demande','mise a jour') NOT NULL,
    dateNotif TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(idUser) REFERENCES User(id),
    FOREIGN KEY(idEchange) REFERENCES Echange(id)
);

SELECT * FROM User JOIN Objet WHERE User.id=Objet.idUser;

SELECT User.email, Objet.nom, Objet.prix, Objet.image FROM User INNER JOIN Objet WHERE User.id=Objet.idUser;

SELECT Objet.id, Objet.nom, Objet.prix, Objet.image, Objet.description, Objet.idUser, Categorie.nom FROM Objet INNER JOIN Categorie WHERE Objet.idCategorie=Categorie.id;

