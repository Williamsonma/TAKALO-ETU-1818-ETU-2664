<?php
   class Fonctions extends CI_Model {

    public function insertUser($nom, $prenom, $email, $password) {
      $request = "INSERT INTO User(nom, prenom, email, password) VALUES ('".$nom."','".$prenom."','".$email."','".$password."')";
      $this->db->query($request);
    }

    public function ifLogged($email, $password) {
      $request = "SELECT COUNT(*) AS logged FROM User WHERE email='$email' and password='$password'";
      $result = $this->db->query($request);
      return $result;
      
    }

    public function getIdUser($email, $password) {
      $request = "SELECT id FROM User WHERE email='$email' and password='$password'";
      $id = $this->db->query($request);
      return $id;
    }

    public function getAllObjet($idUser) {
      $request = "SELECT Objet.id, User.email, Objet.nom, Objet.prix, Objet.image FROM User INNER JOIN Objet WHERE User.id=Objet.idUser AND User.id!='".$idUser."'";
      $query = $this->db->query($request);
      return $query->result_array();
    }

    public function getFicheObjet($idObjet) {
      $request ="SELECT Objet.id, Objet.nom, Objet.prix, Objet.image, Objet.description, Objet.idUser, Categorie.nom FROM Objet INNER JOIN Categorie WHERE Objet.idCategorie=Categorie.id AND Objet.id='".$idObjet."'";
      $query = $this->db->query($request);
      return $query->result_array();
    }

    public function getObjetById($idUser) {
      $request = "SELECT * FROM Objet WHERE id='".$idUser."'";
      $query = $this->db->query($request);
      return $query->result_array();
    }
   }

?>