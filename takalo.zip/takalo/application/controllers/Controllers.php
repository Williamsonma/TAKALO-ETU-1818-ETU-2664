<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Controllers extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function index() {
		$this->session->set_userdata('idUser',null);
		$this->load->view('inscription');	
	}	

	public function traitementInscription() {
		$this->load->view('traitementInscription');	
	}	

	public function viewLogin() {
		$this->load->view('login');	
	}	
	
	public function addUser() {
		$this->load->model('Fonctions');
		$this->Fonctions->insertUser($_POST['nom'],$_POST['prenom'],$_POST['email'],$_POST['password']);
		$this->load->view('login');
	}

	
	public function redirectAccueil() {
		$this->load->view('accueil');
	}

	//maka donnees avy amin`ny form ao amin`ny login
	public function loginController()
    {
        $email = $this->input->post("email");
        $password = $this->input->post("password"); 
        $donnees = array();
        $donnees[0]= $email;
        $donnees[1]= $password;
        return $donnees;  
    }  


	public function traitementLogin(){
		$this->load->library('session');
		$this->load->database();
        $donnees = $this->loginController();	
		$this->load->model('Fonctions');
        $logged = $this->Fonctions->ifLogged($donnees[0], $donnees[1]);
		$auth = $logged->row_array();
        if($auth['logged'] == 1) {
                $query = $this->Fonctions->getIdUser($donnees[0], $donnees[1]);
                $idUser = $query->row_array();
				echo($idUser['id']);
                $this->session->set_userdata('idUser',$idUser['id']); 
                redirect('Controllers/allObjet');
        } else {  
                $error = 'Mail ou mot de passe incorrect';       
                /*$this->session->set_flashdata('incorrect','Mail ou mot de passe icorrect');  //eto 
                $this->session->flashdata('incorrect');*/
                redirect("Controllers/index/$error");  
            }
    }

	public function allObjet() {
		$this->load->model('Fonctions');
		$idUser = $this->session->userdata('idUser');
		$data['listeObjet'] = $this->Fonctions->getAllObjet($idUser);
		$this->load->view('accueil', $data);

	}

	public function getFicheObjet($idObjet) {
		$this->load->model('Fonctions');
		$data['fiche'] = $this->Fonctions->getFicheObjet($idObjet);
		$this->load->view('ficheObjet', $data);
	}

	public function getObjetById($idUser) {
		$this->load->model('Fonctions');
		$idUser = $this->session->userdata('idUser');
		$data['listeObjetUser'] = $this->Fonctions->getObjetById($idUser);
		$this->load->view('ficheObjet', $data);
	}

	public function getObjetUser() {
		$this->load->model('Fonctions');
		$idUser = $this->session->userdata('idUser');
		$data['listeObjetUser'] = $this->Fonctions->getObjetById($idUser);
		$this->load->view('mesObjets', $data);
	}
	
	
}
?>
