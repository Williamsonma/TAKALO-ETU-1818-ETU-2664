<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" integrity="sha384-Bfad6CLCknfcloXFOyFnlgtENryhrpZCe29RTifKEixXQZ38WheV+i/6YWSzkz3V" crossorigin="anonymous">
    <link rel="stylesheet" href="
    ://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <title>TAKALO</title>
    <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">
  </head>
<body>
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
  </header>
<div class="container my-5">
  <div class="row">
    <div class="col-12">
      <h1>Inscription</h1>
    </div>
  </div>
  <div class="row">
    <div class="col-12">
      <form action="<?php echo base_url('Controllers/addUser') ?>" method="post" id="register-form" class="animated fadeIn">
        <div class="form-group">
            <label for="Username">Nom</label>
            <input type="username" class="form-control" id="username" name="nom">
        </div>
        <div class="form-group">
            <label for="Username">Prenom</label>
            <input type="username" class="form-control" id="username" name="prenom">
        </div>
        <div class="form-group">
            <label for="email">Adresse email</label>
            <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="email">
        </div>
        <div class="form-group">
            <label for="password">Mot de passe</label>
            <input type="password" class="form-control" id="password" name="password">
        </div>
        <input type="submit" class="btn btn-primary" value="S`inscrire"></input>
      </form>
      <br>
      <h1>Connectez-vous si vous etes dea inscrit</h1>
      <a href="<?php echo base_url('Controllers/viewLogin') ?>" class="btn btn-primary">Connexion</a>
    </div>
  </div>
</div>
</body>
</html>