
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fiche objet</title>
</head>
<body>
    <form action="" method="post">
    <?php foreach($fiche as $row) {?>
    <p>Image: <?php echo $row['image'] ?></p>
    <p>Nom: <?php echo $row['nom'] ?></p>
    <p>Descriptions: <?php echo $row['description'] ?> </p>
    <p>Proprietaire: <?php echo $row['idUser'] ?></p>
    <p>Categorie: <?php echo $row['nom'] ?></p>
    <p>Prix:</p>
    <p>Proposition d`echange: </p>
    <?php } ?>
    <select name="echange">
        <?php foreach($listeObjetUser as $list) {?>
        <option value="<?php echo $list['id'] ?>"><?php echo $list['nom'] ?></option>
        <?php } ?>
    </select>
    <input type="submit" value="Proposer"></input>
    </form>
</body>
</html>