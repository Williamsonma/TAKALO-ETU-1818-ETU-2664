INSERT INTO User(nom, prenom, email, password) VALUES ('Rakoto','Jean','Jean@gmail.com','0000');
INSERT INTO User(nom, prenom, email, password) VALUES ('Rabe','Jeanne','Jeanne@gmail.com','1111');

INSERT INTO Categorie(nom) VALUES ('Livre');
INSERT INTO Categorie(nom) VALUES ('Vetement');
INSERT INTO Categorie(nom) VALUES ('DVD');

INSERT INTO Objet(idUser, nom, prix, description, image, idCategorie) VALUES (1, 'Jupe', 10000, 'jupe noir tres tendance', 'jupe.png', 2);
INSERT INTO Objet(idUser, nom, prix, description, image, idCategorie) VALUES (2, 'After', 24000, 'livre after', 'after.png', 1);

